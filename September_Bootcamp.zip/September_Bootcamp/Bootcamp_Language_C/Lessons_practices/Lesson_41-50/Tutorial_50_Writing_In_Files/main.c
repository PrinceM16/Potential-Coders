#include <stdio.h>
#include <stdlib.h>

int main()
{
    /* ..*/
    FILE * fblue;
    /* ..*/
    fblue = fopen("Tutorial_50.txt", "w");
    /* ..*/
    fprintf(fblue, "I am almost done now I believe I am 17% good with C \n");
    /* ..*/
    fclose(fblue);
    /* ..*/
    printf("We have save your text \n");
    /*..*/
    return 0;
}
/* Created On - 27/09/2019 - 19:35:16..*/
/* Created by: Prince VXIII Mosa MM..*/
