#include <stdio.h>
#include <stdlib.h>

int main()
{
    /* ..*/
    int *signals;
    /* ..*/
    signals = "Mosa is here";
    /* ..*/
    printf("Hello world! %s\n", signals);
    /* ..*/
    signals = (int *) malloc(5 * sizeof(int));
    /* ..*/
    free(signals);

    return 0;
}
/* Created on -27/09/2019 - 15:05:09..*/
/* Created by: Prince VXIII Mosa MM..*/
