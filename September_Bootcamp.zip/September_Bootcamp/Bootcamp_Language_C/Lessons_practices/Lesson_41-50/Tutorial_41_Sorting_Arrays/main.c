/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_Sorting_Array.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mosam <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/09/26 18:37:22 by mosam             #+#    #+#             */
/*   Updated: 2019/09/27 10:29:05 by shadebe          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <ctype.h>

int main()
{

    /* ..*/
    int i, temp, swapped;
    /* ..*/
    int players = 10;
    /* ..*/
    int goals[players];

    for(i = 0; i <= players; i++){
        /* ..*/
        goals[i] = ( rand()%20) + 1;
        /* ..*/
        i++;

    }
        printf("Original List \n");
    /* ..*/
    for(i = 0; i <= players; i++){
/* ..*/
printf(" %d \n", &goals);
}

while(1){
    /* ..*/
    swapped = 0;
    /* ..*/
    for(i = 0; i <= players-1; i++){

            if(goals[i]>=goals[i + 1]){
            int temp = goals[i];
            goals[i] = goals[i + 1];
            goals[i + 1] = temp;
            swapped = 1;



        }

    }
    /* ..*/
   if(swapped == 0){
    break;
   }
    }
    /* ..*/
     printf("\n Sorted List \n");
    for(i = 0; i <= players; i++){
        printf(" %d \n", goals[i]);
}
    return 0;
}
/* Created On - 26/09/2019 - 19:03:55..*/
/*..Created by Prince VXIII Mosa Moabi*/
