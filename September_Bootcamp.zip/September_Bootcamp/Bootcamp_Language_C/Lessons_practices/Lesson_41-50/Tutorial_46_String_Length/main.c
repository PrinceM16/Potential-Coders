#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

int main()
{
    /* ..*/
    char sentence [100];
    /* ..*/
    char *psentence = sentence;
    /* ..*/
    fgets(psentence, 100, stdin);
    /* ..*/
    puts(psentence);


    return 0;
}
/* Created on - 27/09/2019 - 14:33:48..*/
/* Created by: Prince VXIII Mosa MM..*/
