#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <math.h>

int main()
{
     /* ..*/
    printf("Address \n");
        /* ..*

    /* ..*/
    int *pLion; /* ..*/
        /* ..*/
*pLion = 71;

printf("pLion is: %d \n", *pLion);

  printf("Hello world!\n");
    return 0;

    return 0;
}
/* Created on - 26/09/2019 - 20:33:45..*/
/* Created by Prince VXIII Mosa Moabi..*/
