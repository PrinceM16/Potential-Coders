#include <stdio.h>
#include <stdlib.h>

int main()
{
    /* ..*/
    int i, days;
    /* ..*/
    int total;
    /* ..*/
    float average = 0.0;
    /* ..*/
    int *pointerArray;
    /* ..*/
    printf("How many number do you want for the average? \n");
    /* ..*/
    scanf(" %d", &days);
    /* ..*/
    pointerArray = (int *) malloc(days * sizeof(int));
    /* ..*/
    printf("Enter the as much \n");
    /* ..*/
    for(i = 0; i <= days; i++){
        /* ..*/
        scanf(" %d", &pointerArray[i]);
        /* ..*/
        total += pointerArray[i];

    }
    /* ..*/
    average = (float)total / (float)days;
    /* ..*/
    printf("Average is %.2f \n, average", average);
    return 0;
}
/* Created on - 27/09/2019 - 18:23:56..*/
/* Created by: Prince VXIII Mosa MM..*/
