#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>

int main()
{
        /* ..*/

    /* ..*/
    printf("Address \t Name \t Value \n");
        /* ..*

    /* ..*/
    int *pLion /* ..*/
        /* ..*/
*pLion = 71;

printf("pLion is: %d \n", &pLion);


    return 0;
}
/* Created on 26/09/2019 - 19:57:33..*/
/* Created by - Prince VXIII Mosa Moabi..*/
