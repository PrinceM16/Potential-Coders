#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>
#include <string.h>
#include <ctype.h>
#include "main.h"

int main()
{
    /* ..*/
    int i;
    /* ..*/
    int toys[5] = {3,6,9,12,15};
    /* ..*/
    printf("Address: \t Value \t Digit \n");
    /* ..*/
    for(i=0; i<=5; i++){
        /* ..*/
        printf("\n Toy[%.2d] %p \t %d \t %i \n", i,&toys, toys,toys)+1;
/* ========================================================================= */
    /* ..*/
        printf("\n [%.2d] %p \t %d \t %i \n", i,&toys[i],toys[i],toys[i]+1);
        /* ..*/
        printf("\n [%.2d] %p \t %d \t %i \n", i,*toys,toys[i],toys[i]+1);
    }
for(SALES = 0; SALES <= 20 ; SALES++){
            /* ..*/
        printf("\n Toy[%.2d] %p \t %d \t %i \n", SALES
               ,&toys, toys,toys)+1;
/* ========================================================================= */
    /* ..*/
        printf("\n [%.2d] %p \t %d \t %i \n", SALES,&toys[i],toys[i],toys[i]+1);
        /* ..*/
        printf("\n [%.2d] %p \t %d \t %i \n", SALES,*toys,toys[i],toys[i]+1);
}
    return 0;
}
/* Created on - 27/09/2019 - 10:33:43..*/
/* Created by: Prince VXIII Mosa Moabi..*/
