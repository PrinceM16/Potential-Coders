#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>

int main()
{
        /* ..*/
        int lion = 10;
    /* ..*/
    printf("Address \t Name \t Value \n");
        /* ..*/
        printf("%p \t %s \t %d \n", &lion, "lion", lion); /* ..*/

    /* ..*/
    int *pLion = &lion;/* ..*/
        /* ..*/
        printf("%p \t %s \t %d \n", pLion, "lion", lion);
        /* ..*/
        printf("_______________________________ \n");

printf("%p \t %s \t %p \n", &pLion, "pLion", pLion);


    return 0;
}
/* Created on 26/09/2019 - 19:57:33..*/
/* Created by - Prince VXIII Mosa Moabi..*/
