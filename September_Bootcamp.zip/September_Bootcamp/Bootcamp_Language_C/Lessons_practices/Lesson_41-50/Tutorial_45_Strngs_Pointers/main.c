#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <ctype.h>

int main()
{
    /* ..*/
    char man[] = "I am getting it a bit 16%";
    /* ..*/
    puts(&man);
    /* ..*/
    strcpy(man, "Yes I am fighting to become a programmer");
    puts(&man);
    /* ..*/
    char *man2 = "Really you are becoming a programmer slow by bit";
    /* ..*/
    puts(man2);
    /* ..*/
    man2 = "That is very good Mosa Moabi we are very happy for you";
        /* ..*/
        puts(man2);

    return (0);
}
/* 27/09/2019 - 11:15:28..*/
/* Created by: Prince VXIII Mosa MM..*/
