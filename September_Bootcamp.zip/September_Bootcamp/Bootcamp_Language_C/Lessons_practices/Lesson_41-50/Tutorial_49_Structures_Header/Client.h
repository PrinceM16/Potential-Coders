#ifndef CLIENT_H_INCLUDED
#define CLIENT_H_INCLUDED



#endif // CLIENT_H_INCLUDED

struct client1
{

int userId;
char firstname[15];
char lastname[15];
int age;
float weight;
};


