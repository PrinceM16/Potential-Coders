#include <stdio.h>
#include <stdlib.h>
#include "client.h"


int main()
{
        /* ..*/
    struct client1 mosa;
        /* ..*/
    struct client1 dineo;
    /* ..*/
    mosa.userId = 1;
    dineo.userId = 2;
    /* ..*/
    puts("Please enter the first name of user 1");
    gets(mosa.firstname);
    puts("Please enter the second name of user 1");
    gets(dineo.firstname);

    /* ..*/
    printf("User 1 id is %d \t %s \n", mosa.userId, mosa.firstname);
    printf("User 2 id is %d \t %s \n", dineo.userId, dineo.firstname);

    return 0;
}
 /* Created On -27/09/2019 -18:49:23..*/
 /* Created by: Prince VXIII Mosa MM..*/
