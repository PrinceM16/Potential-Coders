#include <stdio.h>
#include <stdlib.h>

int main()
{
    /* Declaring the variable to be stored an value to be tested..*/
    char choice;
    /* casting a question in an output function "(y/n)"..*/
    printf("Do you like Mosa Moabi (y/n) ?\n");
    /* Requesting an input from the user..*/
    scanf(" %c", &choice);
    /* Checking on of the condition OR the other if not matched with the first condition..*/
    if((choice == 'y') || (choice == 'n'))
    {
        /* If one of the condition matched then the answer should be..*/
        printf("You not a bad person \n");
    }else{
        /* Then if none of the condition matched then this should be the message appearing..*/
    printf("You such an asshole \n");
    }
    return 0;
}
/* Created on 12/09/2019 - 15:03:12..*/
