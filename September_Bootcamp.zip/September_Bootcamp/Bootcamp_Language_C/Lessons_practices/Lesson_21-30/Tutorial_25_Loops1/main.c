#include <stdio.h>
#include <stdlib.h>

int main()
{
    /* Using the While Loop..*/
    /* Assigned an value after declaring the variable..*/
    int mango = 1;
    /* Looping the variable to repeat itself 5 times..*/
    while(mango < 5){
    /* The word mango will appear five times numbered..*/
    printf("You have mango's %d \n", mango);
    /* Incrementing the variable to display its numbering in sequential number lining..*/
    mango++;
    }
    /* Declaring the variable and assigned values..*/
    int products = 1;
    float profit = 1.01;
    /* Looping the variables for 31 times to be displayed in a form of profit..*/
    while(products <= 31)
    {
        /* Displaying the profit in an floating point data type..*/
        printf("your profit today is %.2f \n", profit);
        /* Multiplying the profit by its value multiplied to according to the number of days..*/
        profit *= 2;
        /* incrementing the variable to add new value in it's repeated loops..*/
        products++;
    }
    return 0;
}
/* Created on 12/09/2019 - 17:05:34..*/
