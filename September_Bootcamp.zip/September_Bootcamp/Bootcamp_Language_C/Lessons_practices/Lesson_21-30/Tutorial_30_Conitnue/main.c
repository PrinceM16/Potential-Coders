#include <stdio.h>
#include <stdlib.h>
/* ..*/
#include <string.h>
#include <ctype.h>
#include <math.h>

int main()
{
/* ..*/
int num = 1;/* ..*/
/* ..*/
do{
    /* ..*/
    if(num == 6 || num == 8){
        num++;/* ..*/
        /* ..*/
        continue;
    }
    /* ..*/
    printf("%d is your number \n", num);
    num++;/* ..*/
    /* ..*/
}while(num <= 10); /* ..*/

    return 0;
}
/* Created on - 12/09/2019 - 22:14:34..*/
