#include <stdio.h>
#include <stdlib.h>
/* ..*/
#include <math.h>
#include <string.h>
#include <ctype.h>

int main()
{
    /* ..*/
    int rows; /* ..*/
    int columns; /* ..*/
    /* ..*/
    for(rows = 1; rows <= 10; rows++){
        /* ..*/
        for(columns = 1; columns <= 10; columns++){
            printf(" %d", columns); /* ..*/
        }
        /* ..*/
        printf("\n"); /* ..*/
    }
    return 0; /* ..*/
}
/* Created on 12/09/2019 - 21:23:45..*/
