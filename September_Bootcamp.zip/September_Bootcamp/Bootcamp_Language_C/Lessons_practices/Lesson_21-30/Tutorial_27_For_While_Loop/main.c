#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>

int main()
{
    /* Declared the to Integer Data type..*/
    int weed;
    /* The FOR-loop will to a number greater in that number of multiple times looping without input..*/
    for(weed = 1; weed <= 100; weed+=8){
        /* The printf will display variables characters according to the loop with an addition
            of an increment 1..*/
        printf("Mosa loves weed %d \n", weed++);
    }
    /* The program returns to Zero..*/
    return 0;
}
/* Created on 12/09/2019 - 20:30:43..*/
