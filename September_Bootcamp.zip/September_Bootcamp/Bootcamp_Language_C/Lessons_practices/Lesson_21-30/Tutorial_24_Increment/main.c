#include <stdio.h>
#include <stdlib.h>

int main()
{
    float Bags = 44;
    float shoes = 23;
    float total;

    total = (Bags * shoes) / 3;
    printf("Total amount R%.2f \n", total);

     /* Increment ++..*/
    total++;
    printf("Total amount R%.2f \n", total);

     total++;
    printf("Total amount R%.2f \n", total);

    int a = 3;
    int b = 7;
    int ans;

    ans = (a * b);
    printf("ans : %d \n", ans);

    ans = (a + b + 2);
    ans++;
    printf("ans : %d \n", ans);

    ans = (++a + b + 2);
    ++ans;
    printf("ans : %d \n", ans);



    return 0;
}
/* Created on 12/09/2019 - 16:12:38..*/
