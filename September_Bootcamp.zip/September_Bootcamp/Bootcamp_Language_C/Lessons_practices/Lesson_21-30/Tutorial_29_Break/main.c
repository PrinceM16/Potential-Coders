#include <stdio.h>
#include <stdlib.h>

int main()
{
    /* ..*/
    int a;
    int host; /* ..*/
    int hosts = 10; /* ..*/
    /* ..*/
    printf("How many times do you want to loop? (up o 10) ");
    scanf(" %d", &host); /* ..*/
    /* ..*/
    for(a = 1; a <= hosts; a++){
        printf(" %d \n", a);    /* ..*/
        /* ..*/
        if(a == host){
            /* ..*/
            break;
        }

    }
    /* ..*/
    return 0;
}
/* Created on-12/09/2019 - 22:02:12..*/
