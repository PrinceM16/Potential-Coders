#include <stdio.h>
#include <stdlib.h>

int main()
{
        /* Declaring the variable array with set 0f 15 characters that can be typed..*/
        char lastname[15];
        /* Collecting the details to check the statement case's conditions..*/
        printf("Please enter your lastname \n");
        scanf(" %s", lastname);
        /* Checking the first area of of the array is it greater than I
            then if yes then the player will be on the red team or":"
            display blue team..*/
        (lastname[0] < 'I') ? printf("You are in the red team \n") : printf("You are in the blue team \n");
        /* Declared the variable for an scanf input method..*/
        int friends;
        /* Requesting an input from the user through this notice printf..*/
        printf("Please enter number of friends \n");
        scanf(" %d", &friends);
        /* Checking whether the variable array "Friends" how many friends it has and if less friends than 1
            then the user has one "Friend"..*/
        printf("You have %d friend%s \n", friends, (friends != 1 ) ? "s" : "");
    return 0;
}
/* Created on 12/09/2019 - 16:27:47..*/
