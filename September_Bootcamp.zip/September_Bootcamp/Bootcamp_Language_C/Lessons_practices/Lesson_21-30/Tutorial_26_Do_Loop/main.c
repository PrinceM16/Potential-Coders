#include <stdio.h>
#include <stdlib.h>

int main()
{
    /* Declaring the variables which are not arrays..*/
    float grade = 0; /* declared the variable as an floating point data type for the school grade..*/
    float testmarks = 0; /* declared the variable as an floating point data type for the test marks..*/
    float final_marks = 0; /* declared the variable as an floating point data type for the final marks..*/
    float average = .4; /* declared the variable as an floating point data type for the average..*/
    /* If the user is done to use the program then their can press digit "0"..*/
    printf("Press 0 when complete. \n\n");
    /* DO LOOP while repeat to collect the school test marks till the user presses 0..*/
    do{     /* The DO-LOOP will loop till the user decides to stop them
                the DO LOOP will repeat itself as much as it can itself many times..*/
            printf("Test:%.0f  Average:%.2f  \n", testmarks, average);
            printf("\nEnter test score: "); /* This event will repeat itself each time for a new score..*/
            scanf(" %f", &testmarks); /* SCANF will collect test score's as much as it can till zero is entered..*/
            grade += testmarks; /* grade incrementing the other variable to add an value accordingly..*/
            final_marks++; /* FINAL-MARK Incremented to add an value to it's final mark additionally..*/
            average = grade / final_marks; /* Average calculating the final score mark by having grade divided..*/
    }while(final_marks != 0); /* WHILE LOOP will loop till ZERO is pressed as an matched value to ZERO
                                   then the program will stop ..*/
    /* The program returns back to zero..*/
    return 0;
}
/* Created on 12/09/2019 - 20:12:33..*/
