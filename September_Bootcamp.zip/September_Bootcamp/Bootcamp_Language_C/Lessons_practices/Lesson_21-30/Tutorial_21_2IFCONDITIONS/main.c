#include <stdio.h>
#include <stdlib.h>

int main()
{
    /* Declaring the variable's giving them values..*/
    int studytime = 60;
    int anykids = 0;
    /* Testing two condition at the same time ..*/
    if((studytime >= 40 ) && (anykids == 0)) /* Checking the value is greater than 40..*/
{
    printf("You are good student \n"); /* If the value is lesser than the variable then Display this..*/
}else if((studytime >= 20) && (anykids == 1)) /* else not if the value is matches with the value then..*/
    {
        printf("You are trying but not enough \n"); /* Display this if conditions matched then show this MSG..*/
    }

    studytime = 10;
    anykids = 1;
    if((studytime >=30) && (anykids == 0))
        {
            printf("You performing bad \n");
        }else if((studytime >= 10) && (anykids == 0))
{
    printf("Not happy \n");
}else if((studytime >= 5) && (anykids == 1))
{
    printf("Very very bad student \n");
}
    return 0;
}
/* Created on 12/09/2019 - 14:30:14
