#include <stdio.h>
#include <stdlib.h>
/* ..*/
int bonuswage( int hours);
/* ..*/
int main()
{
    /* ..*/
    printf("Mosa Has worked so good  has earned R%d \n", bonuswage(17));
    printf("Thabo Has worked so good  has earned R%d \n", bonuswage(2));

    /* ..*/
    return 0;
}
/* ..*/
int bonuswage( int hours)
{
    /* ..*/
    int work = hours * 250;
    /* ..*/
    if(hours >= 10){
        work += 1000;
    }
    /* ..*/
    return (0);
}
/* Created on - 29/09/2019 - 16:07:19..*/
/* Created by: Prince VXIII Mosa MM..*/
