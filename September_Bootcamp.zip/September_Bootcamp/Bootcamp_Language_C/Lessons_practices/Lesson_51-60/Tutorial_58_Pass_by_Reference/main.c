#include <stdio.h>
#include <stdlib.h>
/* ..*/
void pass(int a);
/* ..*/
void passed(int *a);
/* ..*/
int main()
{
    /* ..*/
    int yum = 22;
    /* ..*/
    pass(yum);
    printf("My number is: %d to \n", yum);
    /* ..*/
    passed(&yum);
    printf("My address is: %d from \n", yum);
    /* ..*/
    return 0;
}
/* ..*/
void pass(int a){
    /* ..*/
    a = 46;
    /* ..*/
    return;
}
/* ..*/
void passed(int *a){
    /* ..*/
    *a = 77;
    /* ..*/
    return;
}
/* Created on - 29/09/2019 - 16:30:35..*/
/* Created by Prince VXIII Mosa MM..*/
