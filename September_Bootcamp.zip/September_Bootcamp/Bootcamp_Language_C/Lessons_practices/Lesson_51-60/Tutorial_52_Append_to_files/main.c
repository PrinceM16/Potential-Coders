#include <stdio.h>
#include <stdlib.h>

int main()
{
    /* ..*/
    FILE * ffiler;
    /* ..*/
    ffiler = fopen("Tutorial_52_Append_to_files.txt", "a");
    /* ..*/
     fclose(ffiler);
    /* ..*/
    return 0;
}
/* Created on - 29/09/2019 - 11:44:51..*/
/* Created by: Prince VXIII Mosa MM..*/
