#include <stdio.h>
#include <stdlib.h>
/* ..*/
void printwords();
/* ..*/
int main()
{
    /* ..*/
    printwords();
    /* ..*/
    return (0);
}

void printwords(){
    /* ..*/
    printf("I am getting it into one now recently \n")+1;
    /* ..*/
    return (0);
}
/* Created on - 29/09/2019 - 11:34:29..*/
/* Created by: Prince VXIII Mosa MM..*/
