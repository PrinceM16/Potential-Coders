#include <stdio.h>
#include <stdlib.h>

int main()
{
    /* ..*/
    FILE * ffiler;
    /* ..*/
    ffiler = fopen("Tutorial_51.txt", "r");
    /* ..*/
    char opendocs[500];
    /* ..*/
    while(!feof(ffiler)){
        /* ..*/
        fgets(opendocs, 500, ffiler);
        /* ..*/
        puts(opendocs);
    }
    /* ..*/
    fclose(ffiler);
    /* ..*/
    return 0;
}
/* Created on - 29/09/2019 - 08:12:23..*/
/* Created by: Prince VXIII Mosa MM..*/
