#include <stdio.h>
#include <stdlib.h>

int main()
{
    /* ..*/
    FILE * ffile;
    /* ..*/
    ffile = fopen("Tutorial_53_Random_File_Access.txt", "w+");
    /* ..*/
    fputs("I smoked 4 joints today", ffile);

    /* ..*/
    fseek(ffile, 8, SEEK_SET);
    /* ..*/
    fputs(" 7 bags on Wednesday ", ffile);
    /* ..*/
    fseek(ffile, -7, SEEK_END);
    /* ..*/
    fputs("Top of the hollywood", ffile);
    /* ..*/
    fclose(ffile);
    /* ..*/
    return 0;
}
/* Created on - 29/09/2019 - 10:39:21..*/
/* Created by: Prince VXIII Mosa MM..*/
