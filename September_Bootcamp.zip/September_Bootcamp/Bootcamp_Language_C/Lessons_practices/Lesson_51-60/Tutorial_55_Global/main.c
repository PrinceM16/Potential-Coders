#include <stdio.h>
#include <stdlib.h>

/* ..*/
void globallocal();
/* ..*/
int eGdds = 43;
/* ..*/
char nNames[] = "Moabi";
/* ..*/
int main()
{
    /* ..*/

    /* ..*/
    globallocal();
    /* ..*/

    /* ..*/
    return 0;
}

/* ..*/
void globallocal(){
    /* ..*/
    float locall = 3.2;
    /* ..*/
    float tint;
    /* ..*/
    tint = ((float)eGdds * locall) / 3;
    /* ..*/
    printf(" %.1d  and you are %s \n", &tint, nNames);
    /* ..*/
    return (0);
}
/* Created on - 29/09/2019 - 13:52:44..*/
/* Created by: Prince VXIII Mosa MM..*/
