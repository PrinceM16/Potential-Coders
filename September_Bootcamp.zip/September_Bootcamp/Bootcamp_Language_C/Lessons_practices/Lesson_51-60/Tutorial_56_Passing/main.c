#include <stdio.h>
#include <stdlib.h>
/* ..*/
void conver(float euro);
/* ..*/
int main()
{
    /* ..*/
    float price1 = 1.00;
    /* ..*/
    float price2 = 5.00;

    /* ..*/
    conver(price1);
    conver(price2);
    conver(22.34);
    /* ..*/
    return 0;
}

/* ..*/
void conver(float euro)
{
    float usd = euro * 1.37;
    printf(" %.2f Euro - %.2f USD \n", euro, usd);
    /* ..*/
    return (0);
}
/* Created on - 29/09/2019 - 15:23:19..*/
/* Created by: Prince VXIII Mosa MM..*/
