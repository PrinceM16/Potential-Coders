#include <stdio.h>
#include <stdlib.h>

int main()
{
     int a;

    /* Requesting for some input by user through this message..*/
    printf("Please enter your final year mark \n");
    /* The SCANF operator to use in this function to collect an input form
    the user so that value can be assigned to the variable before it's value is checked..*/
    scanf(" %d", &a);

    /* This variable will be declared for the NESTING IF CONDITIONAL STATEMENTS re assigned..*/
    char gender;

    /* The variable A assigned to the component Scanf is to have it's value checked through a condition
    whether is it greater than the value 50 if yes than the user will be an A..*/
    if(a >= 30)
    {
        /* The symbol that the user will get if their value is higher than the value 50..*/
        printf("You get A \n \n");
        /* Nesting the if statement into another if statement condition and comparing both inputs in
        an nested structure of weighting both values..*/
        printf("Please select your gender (m/f) your choice \n");
        scanf(" %c", &gender);

        /* Nesting the IF STATEMENT within the IF STATEMENT from the PRINTF "(m/f)"..*/
        /* If the condition is true that you are male then SIR should appear..*/
        if(gender == 'm'){
            printf("Sir \n", &gender);
        /* ELSE STATEMENT to give this message if no character matches with M..*/
        }else{
        printf("Miss", &gender);
        }
    /* Using an ELSE STATEMENT to check give an this value is not greater than the above value..*/
    }else{
    printf("You are an E  \n");

    }

    return 0;
}
/* Created on 10/09/2019 - 20:10:42..*/
