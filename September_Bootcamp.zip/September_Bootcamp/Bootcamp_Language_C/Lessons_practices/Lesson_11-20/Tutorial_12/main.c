#include <stdio.h>
#include <stdlib.h>

int main()
{

int weight = 895;

printf("My weight is %d and I %d Lbs \n", weight, weight % 12);

int mweight = 12;
float wweight = 24;
int lweight = 3;

int a;
float b;
int c;

a = (weight % 12) + mweight;
b = (weight % 12) * wweight;
c = (weight % 12) - lweight;

printf("You will be %d lbs if you want normal weight \n", a);
printf("If you want to be more weight %.1f lbs \n", b);
printf("Now if you really want to  decrease your wieght %d lbs \n", c);


    return 0;
}
