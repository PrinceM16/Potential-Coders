#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
        /* Declaration of the variables with the stetted given values to calculate..*/
        float avgdailysales;
        int product = 350;
        int sales = 4;
        int months = 2;
        /* The variables got "type casted" changing the variables data types to floating point for calculation procedure..*/
        avgdailysales = ((float)product * (float)sales) / (float)months;
        printf("The profit is: R %.2f opening profit. \n\n", avgdailysales);
       /* The variable just got incremented to forecast the sequence of the calculations ..*/
        printf("The first five months in selling M16 Exterior \n");
        avgdailysales = avgdailysales *= 1.1;
        printf("The profit is: R %.2f profit. \n", avgdailysales);
        avgdailysales = avgdailysales *= 1.1;
        printf("The profit is: R %.2f profit. \n", avgdailysales);
        avgdailysales = avgdailysales *= 1.1;
        printf("The profit is: R %.2f profit. \n", avgdailysales);
        avgdailysales = avgdailysales *= 1.1;
        printf("The profit is: R %.2f profit. \n", avgdailysales);
        avgdailysales = avgdailysales *= 1.1;
        printf("The profit is: R %.2f profit. \n\n", avgdailysales);
        printf("After five months in selling M16 Exterior and continuing \n\n");
        avgdailysales = avgdailysales *= 1.1;
        printf("The profit is: R %.2f profit. \n", avgdailysales);
        avgdailysales = avgdailysales *= 1.2;
        printf("The profit is: R %.2f profit. \n", avgdailysales);
        avgdailysales = avgdailysales *= 1.3;
        printf("The profit is: R %.2f profit. \n", avgdailysales);
        avgdailysales = avgdailysales *= 1.4;
        printf("The profit is: R %.2f profit. \n", avgdailysales);
        avgdailysales = avgdailysales *= 1.5;
        printf("The profit is: R %.2f profit. \n\n", avgdailysales);

        float maintain = 75;

        maintain = (((sales * maintain) * months) - (product + sales));

        printf("The Maintenance amount that will be possibly made \n\n");
        printf("The Maintenance is: R %.2f profit. \n", maintain);
        maintain = maintain *= 1.1;
        printf("The Maintenance is: R %.2f profit. \n", maintain);
        maintain = maintain *= 1.1;
        printf("The Maintenance is: R %.2f profit. \n", maintain);
        maintain = maintain *= 1.1;
        printf("The Maintenance is: R %.2f profit. \n", maintain);
        maintain = maintain *= 1.1;
        printf("The Maintenance is: R %.2f profit. \n", maintain);
        maintain = maintain *= 1.2;
        printf("The Maintenance is: R %.2f profit. \n", maintain);
        maintain = maintain *= 1.3;
        printf("The Maintenance is: R %.2f profit. \n", maintain);
        maintain = maintain *= 1.4;
        printf("The Maintenance is: R %.2f profit. \n", maintain);
        maintain = maintain *= 1.5;
        printf("The Maintenance is: R %.2f profit. \n\n", maintain);
        /* Selecting the specific Month to calculate with the Maintenance..*/
        avgdailysales = avgdailysales *= 1.2;
        /* Selecting the specific Month which its total amount is to be calculated with..*/
        maintain = maintain *= 1.5;
        /* Declaring the variable for the component of Total Amount..*/
        float total;
        /* Adding up together the two components to get the final total amounts..*/
        total = maintain + avgdailysales;
        /* Incremented the Total variable for the monthly basis from the combined calculations
        of the Maintenance and the Average daily sales from the future coming months for M16 E..*/
        printf("The Total amount that will be possibly made R %.2f for second Month \n ", total);
        total = total *= 1.1;
        printf("The Total amount that will be possibly made R %.2f for third Month \n ", total);
        total = total *= 1.1;
        printf("The Total amount that will be possibly made R %.2f for fourth Month \n ", total);
        total = total *= 1.1;
        printf("The Total amount that will be possibly made R %.2f for firth Month \n ", total);
        total = total *= 1.1;
        printf("The Total amount that will be possibly made R %.2f for sixth Month \n ", total);
        total = total *= 1.1;
        printf("The Total amount that will be possibly made R %.2f for seventh Month \n ", total);
        total = total *= 1.1;
        printf("The Total amount that will be possibly made R %.2f for eighth Month \n ", total);
        total = total *= 1.1;
        printf("The Total amount that will be possibly made R %.2f for ninth Month \n ", total);
        total = total *= 1.1;
        printf("The Total amount that will be possibly made R %.2f for tenth Month \n ", total);
        total = total *= 1.1;
        printf("The Total amount that will be possibly made R %.2f for eleventh Month \n ", total);
        total = total *= 1.1;
        printf("The Total amount that will be possibly made R %.2f for twelve th Month \n ", total);
        total = total *= 1.1;
        printf("The Total amount that will be possibly made R %.2f for first Month \n ", total);



    return 0;
}
/*  Created on 10/09/2019 - 16:52:29..*/
