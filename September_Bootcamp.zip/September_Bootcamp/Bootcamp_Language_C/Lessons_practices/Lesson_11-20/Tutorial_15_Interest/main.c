#include <stdio.h>
#include <stdlib.h>

int main()
{
    /* The variable declared as floating point given an value..*/
    float balance = 101.00;
    /* calculating an value in additional operators "*="..*/
    /* The variable multiple itself to the given above value to self per preview..*/
    balance = balance *= 1.1;
    printf("Balance is %.2f \n", balance);
    balance = balance *= 1.1;
    printf("Balance is %.2f \n", balance);
    balance = balance *= 1.1;
    printf("Balance is %.2f \n", balance);
    balance = balance *= 1.1;
    printf("Balance is %.2f \n", balance);
    balance = balance *= 1.1;
    printf("Balance is %.2f \n", balance);
    balance = balance *= 1.1;
    printf("Balance is %.2f \n", balance);
    balance = balance *= 1.1;
    printf("Balance is %.2f \n", balance);
    return 0;
}
/* Created on 10/09/2019 -15:27:33..*/
