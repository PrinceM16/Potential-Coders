#include <stdio.h>
#include <stdlib.h>

int main()
{
    int student, avg, subjct1, subjct2, subjct3;


    printf("Please enter the whole test marks \n");
    scanf(" %d", &subjct1);
    scanf(" %d",&subjct2);
    scanf(" %d", &subjct3);
    avg = subjct1 + subjct2 + subjct3 / 3;

    student = ((avg + 5) * 0.1);

    if(student <= 100)
    {
        printf("The students get symbol A+ \n");
    }else if(student <= 80)
    {
        printf("The student get symbol A \n");
    }else if(student <= 60)
    {
        printf("The student get symbol B \n");
    }else if(student <= 40)
    {
        printf("The student get symbol C \n");
    }else if(student <=20)
    {
        printf("The student get symbol D \n");
    }else if(student <= 10){
    printf("The student get symbol F \n");
    printf("The students fails the whole subject \n");
    }




    return 0;
}
