#include <stdio.h>
#include <stdlib.h>

/* Scanf and Printf functions..*/
int main()
{
    /* Declaring the variables with set values for the characters..*/
    char name[10];
    char crush[10];
    int kids;
/* Now asking the user to enter their names by the method of printf to request..*/
    printf("Please enter your name \n");
    /* Now requesting an input by the user..*/
    scanf(" %s", &name);

    printf("Please eneter your crush \n");
    scanf(" %s", &crush);

    printf("Please eneter the amount of children you want \n");
    scanf(" %d", &kids);
/* Now collected the whole information now displaying what was typed in..*/
    printf(" %s you will be inlove with %s and will have %d children \n", name, crush, kids);

    return 0;
}
