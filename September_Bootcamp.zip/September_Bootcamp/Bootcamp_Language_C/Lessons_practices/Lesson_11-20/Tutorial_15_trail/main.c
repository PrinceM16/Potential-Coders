#include <stdio.h>
#include <stdlib.h>

int main()
{
    /* Declaring the variable giving it an data type set to zero..*/
   int watch = 0;
/* Incrementing the variables "+n"..*/
   watch= watch + 1;
   printf("watch %d \n", watch);
   watch= watch + 1;
   printf("watch %d \n", watch);
   watch= watch + 1;
   printf("watch %d \n", watch);
   watch= watch + 3;
   printf("watch %d \n\n", watch);

    /* Now Declaring the variable for interest..*/
    float interest = 12.03;
    /* Calculating the interest by the declared variable to floating point..*/
    interest = (interest * 14.48);
    /* The interest has been added with an increment value of "+1", "+2".. to as an re-carrying..*/
    printf("The interest is : \tR %.2f amount \n", interest);
    interest = interest + 1;
    printf("The interest is : \tR %.2f amount \n", interest);
    interest = interest + 2;
    printf("The interest is : \tR %.2f amount \n", interest);
    interest = interest + 3;
    printf("The interest is : \tR %.2f amount \n", interest);
    interest = interest + 4;
    printf("The interest is : \tR %.2f amount \n", interest);
    interest = interest + 5;
    printf("The interest is : \tR %.2f amount \n", interest);

    return 0;
}
/* created on 10/09/2019 - 15:09:15..*/
