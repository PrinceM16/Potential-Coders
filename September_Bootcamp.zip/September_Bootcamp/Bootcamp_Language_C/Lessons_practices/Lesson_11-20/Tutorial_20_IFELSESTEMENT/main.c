#include <stdio.h>
#include <stdlib.h>

int main()
{
    /* Declaring the variables for the components and the Average..*/
    float test1;
    float test2;
    float test3;
    float avg;

    /* Requesting an input from the user..*/
    printf("Please enter your final test marks \n");
    /* Collecting the inputs from the users..*/
    scanf(" %f", &test1);
    scanf(" %f", &test2);
    scanf(" %f", &test3);

    /* The Average calculations to be tested through the "ifelse" condition after being calculated..*/
    avg = (test1 + test2 + test3) / 3;
    /* Displaying the final mark calculated all together..*/
    printf("Your final mark is %.2f percentage \n", avg);

    /* Checking the Final's mark symbol through a IFELSE STATEMENT CONDITION..*/
    if(avg >= 80){
        printf("Your Grade is: A");
    }else if(avg >= 70){
    printf("Your Grade is: B");
    }else if(avg >= 60){
    printf("Your Grade is: C");
    }else if(avg >= 50){
    printf("Your Grade is: D");
    }else{
    printf("You are so stupid get back your change");
    }
    return 0;
}
/* Created on 10/09/2019 - 20:40:19..*/
