#include <stdio.h>
#include <stdlib.h>

        int main()
    {
    /* E.G. declaration of the variable set to a value of 4..*/
    int a = 4;
    /* The IF-STATEMENT checking the condition whether is 4 greater than 10..*/
    if(a < 10){
        printf("You need six more \n" );
    }
    /* Then checking whether IF the number 10 is greater than the variable with the value of 4..*/
    if(a > 10){
        printf("You stole 6 eggs \n");
    }

    /* Now asking the user to enter an value to check whether is the value entered greater than the opposed numbers..*/
    printf("Please enter an number \n");
    /* Declaring the variable for the user to be assigned with the
    component of the scanf which will be collecting an input..*/
        int b;
    /* collecting an input form the user via component SCANF assigned with the variable B..*/
    scanf(" %d", &b);
    /* The if statement is to check whether is there any digit above 50if true then user is an A..*/
    if(b >= 50){
        printf("You are an A \n");
    }else
/* The if statement is to check whether is there any digit above 30if true then user is an B..*/
    if(b >= 30 ){
    printf("You are an B");
    }else
/* The if statement is to check whether the value is greater than lower number entered by the user if possible then the user is an D..*/
    if(b <= 20){
        printf("You are an D \n");
    }
    return 0;
}
/* Created on 10/09/2019 - 19:09:25..*/
