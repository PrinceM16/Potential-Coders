#include <stdio.h>
#include <stdlib.h>

    int main()
{
    /* Declaring variable for the component SCANF..*/
    int a;

    /* Requesting for some input by user through this message..*/
    printf("Please enter your final year mark \n");
    /* The SCANF operator to use in this function to collect an input form
    the user so that value can be assigned to the variable before it's value is checked..*/
    scanf(" %d", &a);

    /* This variable will be declared for the NESTING IF CONDITIONAL STATEMENTS re assigned..*/
    char gender;

    /* The variable A assigned to the component Scanf is to have it's value checked through a condition
    whether is it greater than the value 50 if yes than the user will be an A..*/
    if(a >= 60)
    {
        /* The symbol that the user will get if their value is higher than the value 50..*/
        printf("You get A \n \n");
        /* Nesting the if statement into another if statement condition and comparing both inputs in
        an nested structure of weighting both values..*/
        printf("Please select your gender (m/f) your choice \n");
        scanf(" %c", &gender);

        /* Nesting the IF STATEMENT within the IF STATEMENT from the PRINTF "(m/f)"..*/
        /* If the condition is true that you are male then SIR should appear..*/
        if(gender == 'm'){
            printf("Sir \n", &gender);
        }
        /* If the condition is true that you are female then MISS should appear..*/
        if(gender == 'f'){
            printf("Miss", &gender);
        }
    }
    /* Checking whether the value A assigned to the user_scanf is lesser than the value 30..*/
     if(a <= 30)
    {
        /* The symbol that the user will get if lesser than the 30..*/
        printf("You get C \n \n");
        printf("Please select your gender (m/f) your choice \n");
        /* Nesting the if statement into another if statement condition and comparing both inputs in
        an nested structure of weighting both values..*/
        scanf(" %c", &gender);
        /* Nesting the IF STATEMENT within the IF STATEMENT from the PRINTF "(m/f)"..*/
        /* If the condition is true that you are male then SIR should appear..*/
        if(gender == 'm'){
            printf("Sir \n", &gender);
        }

        /* If the condition is true that you are female then MISS should appear..*/
        if(gender == 'f'){
            printf("Miss", &gender);
        }
    }
    return 0;
}
/* 10/09/2019 - 19:45:26..*/
