#include <stdio.h>
#include <stdlib.h>

int main()
{
    /* Clarification of data types for the whole variables..*/
    float age1, age2, age3, average;
    /* The assignment of the two variables..*/
    age1 = age2 = 4;
    /* The input request for the third variable..*/
    printf("Please enter your age \n");
    /* Collecting the feedback from the user via "SCANF" assigned with third variable..*/
    scanf(" %f", &age3);
    /* Now processing the calculations for the "average"..*/
    average = (age1 + age2 +age3 / 3 );
    /* Now displaying the results of the average calculations giving an feedback to the user..*/
    printf("You will have a grandchild at the age of %.0f and meaning that your son or daughter will be %.0f years old \n", age3, average);

    return 0;
}
/* created on:10/09/2019 - 14:10:47 ..*/
