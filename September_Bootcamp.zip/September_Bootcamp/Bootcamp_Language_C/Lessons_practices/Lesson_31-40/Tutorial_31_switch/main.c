#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <ctype.h>

int main()
{
    /* Declaring the variable for the component of scanf ..*/
        int Grade;
    /* The message requesting a user to enter an alphabet as an input..*/
    printf("Please enter an Alphabet \n");
    /* SCANF function event to collect an input in a conversion data type of character and
        which an & symbol attached with the variable because it is not an array..*/
    scanf(" %c", &Grade);
    /* SWITCH -ing the conditions whether do they match in short - long distance
        breaking after they found their great match through the different conditions..*/
    switch(Grade){
                /* Testing whether is there any character that matches with one entered
                    from the user..*/
                case 'A' : printf("You are right");
                /* Program stops after finding its correct match with input..*/
                break;
                case 'B' : printf("You are TRYING");
                break;
                case 'C' : printf("You are going weak");
                break;
                case 'D' : printf("You are failing");
                break;
                case 'F' : printf("You are getting lost");
                break;
                /* If the condition neither of them matches with the stored character's
                    then it doesn't make sense through this condition there is no statement for that wrong
                    input then this will be the message from this event of code DEFAULT..*/
                default : printf("you are wrong");



    }



    return 0;
}
/* Created on - 23/09/2019 -13:02:09..*/
