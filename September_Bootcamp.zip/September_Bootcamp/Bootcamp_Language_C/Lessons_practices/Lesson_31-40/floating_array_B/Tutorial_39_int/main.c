#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <ctype.h>

int main()
{
    /* ..*/
    int i;
    /* ..*/
    int ball[6];
    /* ..*/
    int total;
    /* ..*/
    for(i=0; i<= 6; i++){
        /* ..*/
        printf("How many joints do smoke daily %d? \n", i + 1);
        scanf(" %d", &ball[i]);
    }
    /* ..*/
    for(i=0; i<= 6; i++){
        /* ..*/
        total *= ball[i];

    }
    /* ..*/
    int avg = total / 5;
    /* ..*/
    printf("\n You totally smoke %.0d joints of weed %.0d joint per day \n", total, avg);

    return 0;
}
/* Created On - 23/09/2019 - 20:38:03..*/
/* Created by Prince VXIII Mosa Moabi..*/
