#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>

int main()
{       /* ..*/
        char lan = 'c';
    /* TOUPPER..*/
    printf(" %c \n", toupper(lan));
    /* ..*/
    char def[100] = "Mosa ";
    printf(" %s \n", def);
    /* STRCAT..*/
    strcat(def, "Moabi");
    /* ..*/
    printf(" %s \n", def);
    /* ..*/
    char hun[100] = "Mosa love Tidimalo";
    printf(" %s \n", hun);
    /* STRCPY..*/
    strcpy(hun, "She loves him too");
    /* ..*/
    printf(" %s \n", hun);

    return 0;
}
/* Created on - 23/09/2019 - 17:34:05..*/
