#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <ctype.h>

int main()
{
    /* ..*/
    int i;
    /* ..*/
    int player[5] = {45,66,68,72,87};/* ..*/
    int goals[5] = {26, 22, 27, 29,31};/* ..*/
    int gameplayed[5] = {30, 30, 28, 30, 26};/* ..*/
    float ppg[5];/* ..*/
    float bestPPG = 0.0;/* ..*/
    int bestplayer;/* ..*/
    /* ..*/
    for(i=0; i< 5; i++){
        /* ..*/
        ppg[i] = (float)goals[i] / (float)gameplayed[i];/* ..*/
        /* ..*/
        printf("%d \t %d \t %d \t %.2f \n", player[i], goals[i], gameplayed[i], ppg[i]);
        /* ..*/
        if(ppg[i] >= bestPPG){/* ..*/
            bestPPG = ppg[i];/* ..*/
            bestplayer = player[i];/* ..*/
        }
    }
    /* ..*/
    printf("\n The best player is %d \n", bestplayer);/* ..*/

    return 0;
}
/* Created on- 23/09/2019 - 21:46:36..*/
/* Created by: Prince VXIII Mosa Moabi..*/
