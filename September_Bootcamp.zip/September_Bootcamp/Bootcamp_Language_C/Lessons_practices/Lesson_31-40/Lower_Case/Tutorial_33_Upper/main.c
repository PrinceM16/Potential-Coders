#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <math.h>

int main()
{
    int character;
printf("Please enter any key \n");
scanf(" %c", &character);

  if( isalpha(character))
  {

printf("You are the family of Alphabets \n");

      if(isupper(character))
      {
printf("The letter %c is an Big Capital letter", character);


      }else
      if(islower(character))
      {
printf("This is an small capital letter %c which you typed", character);

      }

  }else
  if( isalnum(character))
{
printf("You are the family of Numbers \n");

    if(isleadbyte(character))
      {

printf("You typed a group number digit %c", character);

      }else
      if(isdigit(character))
      {
printf("You typed a sinlge line group of numbers %c", character);

}
}else if((character))
{
printf("You are the family of Numbers \n");

    if(isleadbyte(character))
      {

printf("You typed a group number digit %c", character);

      }else
      if(isdigit(character))
      {
printf("You typed a sinlge line group of numbers %c", character);

}
}


    return 0;
}
