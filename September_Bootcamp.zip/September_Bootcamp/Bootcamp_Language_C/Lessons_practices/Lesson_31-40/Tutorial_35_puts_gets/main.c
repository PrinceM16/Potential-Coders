#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <ctype.h>

int main()
{
    /* ..*/
    char petname[50];
    char petfood[50];
    /* ..*/
    char sentence[100] = "";
    /* ..*/
    puts(" What is the name of your pet ");
    /* ..*/
    gets(petname);
    /* ..*/
    puts(" What type of food does he eat ");
    /* ..*/
    gets(petfood);
    /* ..*/
    strcat(sentence, petname);/* ..*/
    strcat(sentence, " loves to eat ");/* ..*/
    strcat(sentence, petfood);/* ..*/
    /* ..*/
    puts(sentence);


    return 0;
}
/* Created on - 23/09/2019 - 17:46:37..*/
