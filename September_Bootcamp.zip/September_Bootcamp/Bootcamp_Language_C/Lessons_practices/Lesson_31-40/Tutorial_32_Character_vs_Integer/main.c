#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>

int main()
{
    /* ..*/
  int character;
    /* ..*/
  printf("Please enter any key \n");
  /* ..*/
  scanf(" %c", &character);
    /* ..*/
  if(isalpha(character))
  {
      printf("THIS IS AN ALPHABET FAMILY");
      /* ..*/
  }else
  if(isalnum(character))
  {
      printf("THIS AN NUMBER FAMILY");
      /* ..*/
  }else{
      /* ..*/
  printf("None of this");
  }




    return 0;
}
/* Created on 23/09/2019 - 13:21:33..*/
