#include <stdio.h>
#include <stdlib.h>

int main()
{
    /* ..*/
    int year1;
    int year2;
    int age;
    /* ..*/
    printf("Please enter year \n");
    /* ..*/
    scanf(" %d", &year1);
    /* ..*/
    printf("Please enter second year \n");
    /* ..*/
    scanf(" %d", &year2);
    /* ..*/
    age = year1 - year2;
    /* ..*/
    printf(" %d \n", age);
    /* ..*/
    age = abs(age);
    /* ..*/
    printf("Your number: %d \n", age);


    return 0;
}
/* Created on 23/09/2019 - 19:55:19..*/
/* Created by Prince Mosa Moabi..*/
