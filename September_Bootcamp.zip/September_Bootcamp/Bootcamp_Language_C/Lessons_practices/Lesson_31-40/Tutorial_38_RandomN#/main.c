#include <stdio.h>
#include <stdlib.h>

int main()
{
    /* ..*/
    int i;
    int dice;
    /* ..*/
    for(i=0; i<=20; i++){
        /* ..*/
        dice = (rand()&6 ) + 1;
        /* ..*/
        printf(" %d \n", dice);
    }

    return 0;
}
/* Created on- 23/09/2019 - 20:07:19..*/
/* Created by Prince VXIII Mosa Moabi..*/
