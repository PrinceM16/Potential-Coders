#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>

int main()
{
    /* ..*/
    float num1 = 4.32322;
    float num2 = 5.76554;
    /* ..*/
    printf("Your number is %.2f \n", floor(num1));
    printf("Your number is %.2f \n", floor(num2));
    /* ..*/
    printf("Your number is %.2f \n", ceil(num1));
    printf("Your number is %.2f \n", ceil(num2));

    return 0;
}
/* Created on- 23/09/2019 - 19:39:12..*/
