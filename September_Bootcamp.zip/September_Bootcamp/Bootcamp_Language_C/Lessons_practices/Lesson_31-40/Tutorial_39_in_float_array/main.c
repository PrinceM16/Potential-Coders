#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <ctype.h>

int main()
{
    /* ..*/
    int i;
    /* ..*/
    int balls[6] = {2, 4, 6,7,9,11};
    /* ..*/
    for(i=0; i<= 6; i++){
        /* ..*/
        printf("element %d: %d \n", i, balls[i]);
    }
    return 0;
}
/* Created On - 23/09/2019 - 20:26:28..*/
/* Created by Prince VXIII Mosa Moabi..*/
