#include <stdio.h>
#include <stdlib.h>
/* Given the stored variables in the header file some float point values..*/
#include "FRUITS.h"

int main()
{
    /* Recalling the stored values in the variables in the header file..*/
    printf("Apple's costs R%.2f \n", APPLE);
    printf("Banana's costs R%.2f \n", BANANA);
    printf("Orange's costs R%.2f \n", ORANGE);
    printf("Coco's costs R%.2f \n", COCO);
    printf("Grape's costs R%.2f \n", GRAPES);

    return 0;
}
/* Created on 10/09/2019 -23:14:19..*/
