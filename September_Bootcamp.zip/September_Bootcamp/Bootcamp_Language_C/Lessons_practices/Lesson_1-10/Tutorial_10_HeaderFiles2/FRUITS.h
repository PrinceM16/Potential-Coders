#ifndef FRUITS_H_INCLUDED
#define FRUITS_H_INCLUDED
#define APPLE   1.00
#define BANANA  1.50
#define ORANGE  2.00
#define COCO    5.50
#define BERRYS  4.84
#define GRAPES  6.48
#endif // FRUITS_H_INCLUDED
