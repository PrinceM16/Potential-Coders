#include <stdio.h>
#include <stdlib.h>

int main()
{
    /* Printing different outputs in different conversions in different methods..*/
    printf("Hello world!\n");
    printf("Mosa bought %d computers \n", 3);
    printf("Mr. Siyabonga my teacher you have to get R %.2f for the lessons \n", 550.0);
    printf("You Mosa did you really love that lady %s hmmmmm!! \n", "Lerato");
    printf("Did you get everything right %c hmmm!! \n", &"Mosa");
    return 0;
}
/* Created on 09/09/2019 - 08:50:47..*/
