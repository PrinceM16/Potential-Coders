#include <stdio.h>
#include <stdlib.h>

int main()
{
    /* Declaring the variable and setting the amount of characters it can take
    while stored constant variable name..*/
    printf("============================================\n");
    /* Limiting the variable to certain number of value of the characters..*/
    char name[10] = "Mosa Moabi";
    /* Displaying the name stored in the variable array..*/
    printf("Welcome to your world %s \n\n", name);
    /* Terminating the specific characters of alphabets with the words stored in array..*/
    name[2] = 'Z';
    name[6] = 'u';
    /* Now displaying the name with the both terminated words..*/
    printf("YOUR NAME HAS BEEN CHANGED %s \n\n", name);
    /* After declaring the variable no value is set for the array to take but will have
        words stored in it..*/
    char land[] = "Kagiso Moabi";
    /* Displaying the stored name in the variable..*/
    printf("Your name is %s \n\n", land);
    /* STRCPY shuffling the whole word in full termination into a new word..*/
    strcpy(land, "Thabo Moabi");
    /* Displaying the whole changed word which was fully changed..*/
    printf("Now he is %s \n");
    return 0;
}
/* Created on 09/09/2019 - 09:45:53..*/
