#include <stdio.h>
#include <stdlib.h>

int main()
{
    /* Declaring the variables and setting arrays..*/
    char Name[6];
    char fruit[10];
    /* Collecting the inputs from the user..*/
    printf("Please type in your name \n");
    scanf(" %s", &Name);
    printf("Please type in your favorite fruit \n");
    scanf(" %s", &fruit);
    /* Displaying both  with the array variable ..*/
    printf("You are %s and your favorite fruit is %s \n ", Name,fruit);
    /* Declaring the variable into float..*/
    float price;
    /* The variable being assigned and processed with calculation..*/
    price = (price = 2 * 2) / 3;
    /* Displaying the variables along with the new calculation made from the re assigned variable..*/
    printf("You will need R %.2f to buy your favorite %s bye \n", price, fruit);
    return 0;
}
/* Created on 09/09/2019 - 09:57:23..*/
