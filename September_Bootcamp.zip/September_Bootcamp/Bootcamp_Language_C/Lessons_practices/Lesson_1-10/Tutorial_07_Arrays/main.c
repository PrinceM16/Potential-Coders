#include <stdio.h>
#include <stdlib.h>

int main()
{
    /* Declaring the variables to be made into Arrays.. */
        char type[10];
        /* Arrays given different values..*/
        float Computers[] = {300.50,450.90,230.40,380.00,470.95,560.55,643.34,780.44,833.33,949.33};
        float price;

            float vat = 0.14;

        float total_amount;

        printf("Please enter your different type of computer \n");
        scanf(" %s", &type);

        if(type >= 'I')
        {
            price = price = 300.50;
            total_amount = price * vat;
            printf("Your computer will be : R %.2f amount \n", total_amount);
        }else if(type >= 'O')
        {
            price = price = 450.90;
            total_amount = price * vat;
          printf("Your computer will be : R %.2f amount \n", total_amount);
        }


    return 0;
}
/* Created on 10/09/2019 - 20:30:47..*/
