#ifndef STUDENTS_H_INCLUDED
#define STUDENTS_H_INCLUDED
#define STUDENT1    "Mosa Moabi"
#define STUDENT2    "Thabo Moabi"
#define STUDENT3    "Kagiso Moabi"
#define MARKS       73
#endif // STUDENTS_H_INCLUDED
