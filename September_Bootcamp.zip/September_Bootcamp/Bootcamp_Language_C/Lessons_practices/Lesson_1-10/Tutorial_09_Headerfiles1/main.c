#include <stdio.h>
#include <stdlib.h>
/* Referenced the header file which has information stormily
    written in a understandable method..*/
#include "students.h"

int main()
{
    /* Declared the variable array and linked it to a string of characters
        from the referenced header file with stored character in it
        and set as an value characteristic of this variable array..*/
    char stdchild[] = STUDENT1;
    /* Displaying the stored value which was recalled from the header file..*/
    printf("This student's name is %s who is a good student \n", stdchild);

    /* Terminating the previous stored array from the header file and swapping it
        with second stored values of characteristics in the header file..*/
    strcpy(stdchild, STUDENT2);
    /* Displaying the stored value which was recalled from the header file..*/
    printf("This student's name is %s who is a good student \n", stdchild);

/* Terminating the last changed array previously stored array from the header file and swapping it
        with second stored values of characteristics in the header file..*/
    strcpy(stdchild, STUDENT3);
    /* Displaying the stored value which was recalled from the header file..*/
    printf("This student's name is %s who is a good student \n", stdchild);
    /* Displaying the percentage mark stored in the header file
        and linking it with the name of the student..*/
    printf("The student %s got %.2d percentage \n ", stdchild, MARKS);
    return 0;
}
/* Created on 10/09/2019 - 22:30:43..*/
