/* Commenting on the work to be done for the day in this type of style as my heading..*/
/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_Comments.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mmoabi <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/09/09 08:30:51 by mmoabi            #+#    #+#             */
/*   Updated: 2019/09/09 09:20:01 by mmoabi           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/* The library files which are defined in their header files as extensions..*/
#include <stdio.h>
#include <stdlib.h>
/* The Body of the program which is the heart and brain of the application..*/
int main()
/* The property of the body of the program where a number functions are typed and given
different tasks to perform or in other sub - models within the same program script..*/
{
    /* Giving the program an instruction to display the word "Hello world using PRINTF() Function"..*/
    printf("Hello world!\n");

    //// The other method of commenting and the color of the "////" commenting
    //// differ from the "/* */" COMMENTING method and have different purposes.

    //* This is another commenting method which can be used when commenting on an certain function.

    /* Or you can used the continual COMMENTING method

        to write an documentation comment statements for or to the programmer or technician

        writing in jargon language via as much information as possible via this
        commenting method*/

    return 0;
}
/* Created on 09/09/2019 - 08:39..*/
