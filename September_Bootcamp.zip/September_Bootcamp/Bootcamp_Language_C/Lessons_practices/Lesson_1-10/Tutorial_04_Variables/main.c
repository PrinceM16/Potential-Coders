#include <stdio.h>
#include <stdlib.h>

int main()
{
/* Declared a variable for the character data type to print your name from the
input of scanf..*/
char name[8];
printf("Please type your name \n");
/* Collecting the input from the user for the variable to be displayed..*/
scanf(" %s", &name);
/* The welcoming message without the conversion..*/
printf("Welcome to the school \n");
/* Declared the variable for the Integers data type..*/
    int a;
    int b;
    int c = 2;
/* The variable getting assigned to a value..*/
    b = 3;
/* tThis variable is used to get calculations..*/
    a = (b * c);
    printf("Integer Variables %d \n", a);
/* Declared the variable for the float data type..*/
    float vat;
    float tax;
    /* The floating variable assigned with a value..*/
    float average = 1.1;
/* both of the variables being assigned with the same value..*/
    vat = tax = 3;
/* Doing the calculations with unassigned variable but assigning the calculations..*/
    average = (vat * tax) / 2;
    printf("The floating point variables %.2f \n", average);

/* Declared 3 variables to integer data type and the other 1 to declared to
    an float data type then the other variables will be casted to another
    different data type during the calculation..*/
    int cake = 78;
    int sale = 5;
    int days = 7;
    float total;
/* Casting the other variables into a float data type from an integer data type..*/
    total = ((float)cake * (float)sale) / (float)days ;
    printf("Your cakes made %.2f amount of money \n\n", total);
/* Now displaying from the first input requested for the variable which was
    declared into strings..*/
    printf("You are done with everything %s enjoy your day \n", name);


    return 0;
}
/* Created on 09/09/2019 - 09:30:41..*/
