#include <stdio.h>
#include <stdlib.h>



int main()
{
    /* The first lesson based on printing on screen without an input or behavior..*/
    /* PRINTF() is the method to print on the screen or give a feedback to the user..*/
    printf("I welcome you here to my first lesson \n");
    printf("This is our first program to write based on PRINTING ON SCREEN AN OUTPUT. \n");

    return 0;
}
/* Created on 07/09/2019 - 08:45:57..*/
