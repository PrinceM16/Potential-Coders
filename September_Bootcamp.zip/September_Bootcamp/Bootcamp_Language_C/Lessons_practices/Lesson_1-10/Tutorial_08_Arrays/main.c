#include <stdio.h>
#include <stdlib.h>

int main()
{
    /* Declaring the variable as an array with no value but stored a characters..*/
    char type[] = "Fat Cakes";
    /* .Displaying the stored characters in the array and displaying the amount of that item .*/
    printf("You will get %s and they cost R%.2f \n\n", type, (0.50 * 4));
    /* Terminating previous stored words in the array and swapping the whole words..*/
    strcpy(type, "Scones");
    /* Displaying the swapped new words which were terminated from the previous ..*/
    printf("You will get %s and they cost R%.2f \n\n", type, (1.50 * 5));
    /* Terminating every column of the array into different Alphabet's..*/
    type[0] = 'B';
    type[1] = 'i';
    type[2] = 's';
    type[3] = 'c';
    type[4] = 'u';
    type[5] = 'i';
    type[6] = 't';
    type[7] = 's`';
    /* Displaying the terminated individual Alphabets and before the last word we used the symbol ` to
        separate the last previous alphabet from appearing..*/
    printf("You will get %s and they cost R%.2f \n\n", type, (0.70 * 6));
    return 0;
}
/* Created on 10/09/2019 - 21:00:34..*/
