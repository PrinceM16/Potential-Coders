/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_numbers.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mosam <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/09/12 17:52:22 by mosam             #+#    #+#             */
/*   Updated: 2019/09/12 18:45:05 by shadebe          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <stdlib.h>

void ft_putchar(int n)
{
/* Function for output..*/
write(1, &n, 1);
}

void ft_print_numbers (void)
{
    /* Declaring the local variable for the numbering..*/
    int p;
    /* Variable p should display the numbers from '1' to '10'..*/
    p = '0';
    /* Variable must beging pointing from value zero to value ten through a while loop..*/
while(p <= '9')
{
    /* adding an value to the variable per number in the same line..*/
    ft_putchar(p++);
}
}


int main()
{
/* now displaying the processings from te functions..*/
ft_print_numbers();
    return 0;
}
