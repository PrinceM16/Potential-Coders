/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_forward_alphbet.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mosam <marvin@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/09/12 17:09:16 by mosam             #+#    #+#             */
/*   Updated: 2019/09/12 18:29:33 by shadebe          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <stdlib.h>

void ft_putchar(char c)
{
    /* 'The function to display as an output..*/
    write(1, &c, 1);
}

void ft_forward_alphbet (void)
{
    /* Declaring the variable that will be a pointer from 'a' to 'z'..*/
    int a;
    /* an variable is set to start from the alphblet 'a' to 'z'..*/
    a = 'a';
    /* now the variable looping from 'a' to 'z' by a while loop checking any greater alphbet than 'a'..*/
    while(a <= 'z')
    {
    ft_putchar(a++);
    }
    /* making the function of the output to make an newline when display an output..*/
putchar('\n');
}

int main()
{
   /* Telling the main-body of the program to collect the output from the ft_forward_alphbet function..*/
ft_forward_alphbet();
    return 0;
}
