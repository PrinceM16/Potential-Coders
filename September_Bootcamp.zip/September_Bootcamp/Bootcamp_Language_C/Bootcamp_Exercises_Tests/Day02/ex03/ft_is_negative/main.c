/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_is_negative.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mosam <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/09/12 18:09:55 by mosam             #+#    #+#             */
/*   Updated: 2019/09/12 19:00:13 by shadebe          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <stdlib.h>

void ft_putchar(int u)
{
    /* Function for the output..*/
write(1, &u, 1);
}

void ft_is_negative(void)
{
    /* Declaring the variable..*/
int n;
n = '9';
/* The variable should show from 9 to 0 or display N..OR..P..*/
while(n <= '0')
{
    /* the function should decsend from 9 to 0 in addition to the every value..*/
    putchar(n+ '0');
    n--;
}
}


int main()
{
/* output function to display the processed parameters..*/
ft_is_negative();
    return 0;
}
