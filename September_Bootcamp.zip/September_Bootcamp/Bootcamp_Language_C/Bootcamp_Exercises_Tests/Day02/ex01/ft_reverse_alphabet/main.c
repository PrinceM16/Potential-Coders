/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_reverse_alphbet.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mosam <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/09/12 17:29:46 by mosam             #+#    #+#             */
/*   Updated: 2019/09/12 18:32:11 by shadebe          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <stdlib.h>

void ft_putchar(char c)
{
/* Function for the output setted in a value of 1..*/
write(1, &c, 1);
}

void ft_reverse_alphabet (void)
{
/* declaring the local variable to loop between 'z' to 'a'..*/
int z;
/* Now alphabet 'z' should loop back to the alhpabet 'a'..*/
z = 'z';
/* the varaible looping back to the alphabet 'a'..*/
while(z >='a')
{
    /* subracting an additional value to the pointer of the variable..*/
    ft_putchar(z--);
}
}

int main()
{
/* Now showing the output from the ft_reverse_alphabet function..*/
ft_reverse_alphabet();
    return 0;
}
