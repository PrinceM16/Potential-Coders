/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ft.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mmoabi <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/09/24 09:53:53 by mmoabi            #+#    #+#             */
/*   Updated: 2016/09/24 10:08:33 by mmoabi           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <ctype.h>

void ft_ft(int *nbr)
{
    /* ..*/
    write(1, *nbr, 1);
    /* ..*/
    *nbr = '42';    /* ..*/
}
/* ..*/
void *nbr_ft (void)
{
    /* ..*/
   void ft_ft();    /* ..*/
}

int main(void)
{
    /* ..*/
    int myArray[] = {42};
    void *nbr_ft(myArray);   /* ..*/

	printf(" %.2d\n",myArray);
    return 0;
}
