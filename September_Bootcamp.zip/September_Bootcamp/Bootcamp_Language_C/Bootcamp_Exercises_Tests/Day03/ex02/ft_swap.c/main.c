/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_ft.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mmoabi <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/09/24 20:33:12 by mmoabi            #+#    #+#             */
/*   Updated: 2019/09/24 21:16:45 by mmoabi           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <stdlib.h>

void ft_swap(int *a, int *b)
{
int temp = *a;

*a = *b;
*b = temp;


}

int main()
{
     int myArray;

  void ft_swap(myArray);
	printf("%s \n",myArray);
    return 0;
}
