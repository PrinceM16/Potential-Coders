/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_iterative_power.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mmoabi <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/09/25 21:21:11 by mmoabi            #+#    #+#             */
/*   Updated: 2016/09/25 21:45:33 by mmoabi           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <unistd.h>
#include <math.h>
#include <malloc.h>

int	ft_iterative_power(int nb,int power)
{
    /* ..*/
	write(1, &nb, 1);
    write(1, &power, 2);
	return (0);
}



void	ft_power_number(void)
{
    /* ..*/
	int i;

	 i = 0;
        /* ..*/
		ft_iterative_power(i= '1');
    /* ..*/
	putchar('\n');
}


int main()
{
    /* ..*/
	ft_power_number();

	return(0);
}
