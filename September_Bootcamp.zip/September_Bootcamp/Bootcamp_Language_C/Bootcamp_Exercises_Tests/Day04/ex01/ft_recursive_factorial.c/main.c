/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_recursive_factorial.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mmoabi <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/09/25 19:33:42 by mmoabi            #+#    #+#             */
/*   Updated: 2016/09/25 20:30:33 by mmoabi           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>
#include <unistd.h>

int	ft_recursive_factorial(int nb)
{
	write(1, &nb, 10);
	return (0);
}

void	ft_factorial_parameter(void)
{
    /* ..*/
	int i;

            int total;
            total = 13 / 3;

        /* ..*/
		ft_recursive_factorial(i+ 'total');


    /* ..*/
	putchar('\n');
}

int main()
{
    /* ..*/
	ft_factorial_parameter();

	return(0);
}
