/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_iterative_factorial.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mmoabi <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/09/25 17:53:53 by mmoabi            #+#    #+#             */
/*   Updated: 2016/09/25 18:23:33 by mmoabi           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <math.h>
#include <string.h>

void ft_iterative_factorial(int nb)
{
/* ..*/
int i = 1;
/* ..*/
for(i=1; i <= 1; i++)
{
    /* ..*/
    gets(i);
}
return(1);
}

int main()
{
    /* ..*/
    int myArray;
    /* ..*/
    void ft_iterative_factorial(myArray);
    /* ..*/
	printf(" %d \n",myArray);
    /* ..*/
    return myArray;
}
