#include <stdio.h>
#include <stdlib.h>
int main()
{
        char l;// meaning lower-case
        char u;// meaning upper-case
        int i;

        i = 0;// just as a counter varible of how many times it should iterate
        l = 'a';
        u = 'B';
        while(i <= 12 )// this condition will always tell you how many times a loop
        {			   // will run, and from it we are able to tell what to use as an incrementer, i this case its 'i'.
                printf("%c" ,l);
                printf("%c" , u);
                l = l + 2;// to change the value of the variable 'l' and 'u' we use the assigment op'=' to assign a new value
                u = u + 2;// and every time the loop runs the value changes.
                i++;// we use i to tell how many times the loop will run.
        }
        printf("%s", "\n");
        return (0);
}
