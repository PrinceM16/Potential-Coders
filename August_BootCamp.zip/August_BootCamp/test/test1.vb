﻿Public Class Form1
    ' The global variables
	Dim Namee As String
	Dim Surname As String

	' The global variables for RadioButtons
	Dim Clevel1 As Integer
	Dim Clevel2 As Integer
	Dim Clevel3 As Integer

	' The global variables for the checkboxes
	Dim TShirt As Integer
	Dim Caps As Integer
	Dim Bag As Integer


	Private Sub Button1_Click(Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click         ' The local variables:isender As Object, e As EventArgs) Handles Button1.Click
        ' The local variables


End Sub
















End Class

