#include <stdio.h>
#include <stdlib.h>

int main()
{
    int daty = 117;

    while(daty < 500)
    {
        printf("Hello world!\n");
    daty++;
    while(daty == 12)
    {
      printf("Hello world!\n");
    break;
    }
    }
    return 0;
}
