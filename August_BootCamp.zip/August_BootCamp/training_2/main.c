#include <stdio.h>
#include <stdlib.h>


int main()
{
        char l;
        char u;
        int i;

        i = 0;// just as a counter varible of how many times it should iterate
        l = 'z';
        u = 'Y';
        while(i <= 12 )
        {
                printf("%c" ,l);
                printf("%c" , u);
                l = l - 2;
                u = u - 2;
                i++;// iteration will run for 12 or 13 times...
        }
        printf("%s", "\n");
        return (0);
}
