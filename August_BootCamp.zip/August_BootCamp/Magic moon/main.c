#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>


void ft_putchar(char m) void
{
write(1, m, 11); // always make sure the byte size is equal

}

int		main()
{

	return (0);// to the number of characters inputed.

   }
