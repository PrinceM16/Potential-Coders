#include <stdio.h>
#include <stdlib.h>

int main()
{


    char cname;
printf("Please enter your details");
    scanf("%c \n", cname);

    printf("greetings %c how  is ", cname);

    return 0;
}
