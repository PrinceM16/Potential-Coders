#include <stdio.h>
#include <stdlib.h>

int main()
{


    char nee;
    int Numbbers;



    printf("welcome please enter your name \n");
    scanf(" %c \n", nee);


printf("%c hee", nee);






    return 0;
}
