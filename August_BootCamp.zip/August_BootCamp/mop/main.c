#include <stdio.h>
#include <stdlib.h>

int main()
{
    char nam1;
    char nam2;
    char nam3;




    nam1 = "Mosa";
    nam2 = "Lerato";
    nam3 = "Dineo";


printf("You were  \n and met  \n who was with \n remember \n");

        return 0;
}
