#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int	ft_putchar(int c)
{
	write(1, &c, 1);
	return (0);
}

void	ft_print_numbers(void)
{
	int i;
	i = 9;

	while(i<0)
	{
		ft_putchar(i-'9');
		i--;
	}
	putchar('\n');
}
int main()
{
    ft_print_numbers();
        return (0);
}
