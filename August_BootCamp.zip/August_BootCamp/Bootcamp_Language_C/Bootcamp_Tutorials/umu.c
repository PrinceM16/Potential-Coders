int main()
{

	write(1, 'm', 1);
	return 0;
}
