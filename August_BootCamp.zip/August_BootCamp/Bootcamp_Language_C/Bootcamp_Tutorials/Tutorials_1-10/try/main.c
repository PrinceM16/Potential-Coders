#include <stdio.h>
#include <stdlib.h>

int ft_fibonacci(int index)
{

    write(1, index, 0);
}


void indexlist(void)
{

int m;


for(m = 0; m < 7; m++)
m++;
{
    printf("u in\n");



}



int main()
{

    printf("Hello world!\n");
    ft_fibonacci;
    return 0;
}
}
