// Variables
// doing a number of variables
#include <stdio.h>
#include <stdlib.h>

int main()
{
    //// Variables for the local components
    char nname[5] = "Mosa";
    int age;
    int birthd = 1991;
    int currnty = 2019;

    //// the assignment of the calculations of the variables stored
    age = currnty - birthd;
    //// display the collected stored data
    printf("%s you are %d years old and you were born %d", nname, age, birthd);



    return 0;
}
