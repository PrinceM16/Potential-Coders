/* This exercise is based on the "printf("")" line of code used as an output */


#include <stdio.h>
#include <stdlib.h>

int main()
{
    // The output of hello world //
    printf("Hello world!\n");

// So here I was just qouting that the code is used to display as an output
    printf("This is my first time learning C \n");

    printf("This printf command code tells the pc to display \n");

    printf("printf and the is an output with an extra newline to display \n");

    return 0;
}
