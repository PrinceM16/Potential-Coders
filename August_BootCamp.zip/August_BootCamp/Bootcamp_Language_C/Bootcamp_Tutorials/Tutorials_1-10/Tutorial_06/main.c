// Termination!!
// we are working with the "Termination" in the arrays of the variables
// an array is "varaible[] = "statement" don't forget"

#include <stdio.h>
#include <stdlib.h>

int main()
{
    // declare the variable and set an array
 char nname[11] ="Mosa Moabi";
 printf("you are %s \t from dobsonville \n\n", nname);

// Now Terminating by changing the data collection in the array
nname[2] ='z';
printf("your name has been changed in the second aphlabet: %s do you see \n", nname);

//

char fruits[] = "oranges";
printf("You like alot of %s \n",fruits);

// now reterminating again using "strpy(variable(array),"new word to be changed to" "
strcpy(fruits,"apples");
printf("You don't like %s ",fruits);
    return 0;
}
