#include <stdio.h>
#include <stdlib.h>
///// This is an header function from my header source file
#include "funct1.h"
int main()
{
    // Here we just used the references from the header file which we stored data in the header source file
    printf("Welcome to meet %s!\n\n", NNAME);
    printf("We want to give you his numbers %d \n\n", NUMBERS);
    printf(" Mr. Mosa lives at %s \n\n", HOME);

    return 0;
}
