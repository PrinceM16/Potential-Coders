// Just made my own header functions and tried a few like the three below
#define NNAME "Mosa"
#define NUMBERS "564743 - 387263"
#define HOME "Dobsonville"
