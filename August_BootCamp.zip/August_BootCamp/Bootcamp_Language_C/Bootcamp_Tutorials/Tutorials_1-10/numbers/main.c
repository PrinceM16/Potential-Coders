/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_numbers.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: shadebe <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/03/31 12:50:51 by shadebe           #+#    #+#             */
/*   Updated: 2016/03/31 13:50:01 by shadebe          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h>

int	ft_putchar(int c)
{
	write(1, &c, 1);
	return (0);
}

void	ft_print_numbers(void)
{
	int i;
	i = 0;

	while(i<=9)
	{
		ft_putchar(i+'0');
		i++;
	}
	putchar('\n');
}

int main()
{
	ft_print_numbers();
	return(0);
}

