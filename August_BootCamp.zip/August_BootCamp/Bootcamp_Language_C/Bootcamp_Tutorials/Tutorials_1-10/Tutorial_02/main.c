#include <stdio.h>
#include <stdlib.h>

int main()
{
    // The code just display a normal string of words with a two space down functions for newline \n
    printf("Welcome to the beginning of programming \n \n");

    // The code to display information in an orderical spaced manner \t
    printf("Mosa Moabi \t at this very pleasant moment \n\n");

// Now combining the stored name with an input from the user and displaying it together
// I declare the variable for the input.
char namme[6];
//I now request for some input and after I now link the variable with an input component code "scanf("")
printf("Please enter your Name");
scanf(" %s \n", namme);
printf("Mosa Moabi is happy to meet: %s \t in peace \n \n");



    return 0;
}
