//Now we are just dealing some of the data types and mixing them in the output without assigning them.

#include <stdio.h>
#include <stdlib.h>


int main()
{

    // To deal with data types in the output code function
    printf("Hello %s  and welcome to the world!\n", "Mosa");

    // Now we are displaying two stings same tametime
    printf("%s have you ate your %s \t early \n", "Palesa", "Choclate");

    // Now displaying two three different data types
    printf("This %s got away with R%d of money to %s alone \n\n","Lesego",500,"Gauteng");


    return 0;
}
