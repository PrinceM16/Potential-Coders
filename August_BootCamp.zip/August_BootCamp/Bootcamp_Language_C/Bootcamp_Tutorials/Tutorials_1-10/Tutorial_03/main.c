// Now just making some comments and different objects to use to make comments which are important all times to comment
// on every coding we or I do.

//* objects used to comment: "/* Welcome */" Continous comment, and "//" Single line comments*//


#include <stdio.h>
#include <stdlib.h>

int main()
{
    //// Thre can be different slashs to make comments on any code blocks or anywhere else where
    //// you want to comment.

    /*
    This is another way you can comment on the lines of code and comment on every component
    to details so that the program becomes simple.

    */
    printf("Tutorial 03 judt busy with Comments!\n");
    return 0;
}
