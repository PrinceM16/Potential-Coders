#include <stdio.h>
#include <stdlib.h>

int main()
{
 char nname;



 printf('Please type in your name\n');
 scanf(' %s \n', nname);


printf('%s you are in a age of %d old \n', nname);
    return 0;
}
