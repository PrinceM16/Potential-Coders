ifconfig | grep "ether" | grep "media"
