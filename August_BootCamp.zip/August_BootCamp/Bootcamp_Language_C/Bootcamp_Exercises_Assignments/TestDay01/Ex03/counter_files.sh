find . | wc -1|sed "s: ::g"
