find . -type f -name "*.sh" | sed "s:./::g"
