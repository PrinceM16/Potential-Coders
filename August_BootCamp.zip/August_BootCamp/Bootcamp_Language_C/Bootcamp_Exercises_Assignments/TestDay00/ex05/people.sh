ldapsearch -x uid=z* cn | SORT -r

